/**
 * DSM — Core Entry Point
 * Exposes the primary search API for programmatic use.
 */

const { search, resolveModule } = require('./orchestrator');
const { runQueue } = require('./queue');

module.exports = { search, resolveModule, runQueue };
